// Minimal but complete chess rules engine
const WHITE = 'w', BLACK = 'b';
const PIECES = { p:'pawn', n:'knight', b:'bishop', r:'rook', q:'queen', k:'king' };

function cloneBoard(board) {
  return board.map(row => row.slice());
}

class ChessGame {
  constructor() {
    this.reset();
  }

  reset() {
    this.board = this.initialBoard();
    this.turn = WHITE;
    this.castling = { wK: true, wQ: true, bK: true, bQ: true };
    this.enPassant = null; // {r,c} square that can be captured onto
    this.halfmove = 0;
    this.fullmove = 1;
    this.history = []; // stack of {board, turn, castling, enPassant, halfmove, fullmove, move}
    this.captured = { w: [], b: [] };
    this.gameOver = false;
    this.result = null; // 'checkmate' | 'stalemate' | 'draw'
    this.winner = null;
  }

  initialBoard() {
    const b = Array.from({length:8}, () => Array(8).fill(null));
    const back = ['r','n','b','q','k','b','n','r'];
    for (let c = 0; c < 8; c++) {
      b[0][c] = { type: back[c], color: BLACK };
      b[1][c] = { type: 'p', color: BLACK };
      b[6][c] = { type: 'p', color: WHITE };
      b[7][c] = { type: back[c], color: WHITE };
    }
    return b;
  }

  inBounds(r,c) { return r>=0 && r<8 && c>=0 && c<8; }

  pieceAt(r,c) { return this.board[r][c]; }

  findKing(color) {
    for (let r=0;r<8;r++) for (let c=0;c<8;c++) {
      const p = this.board[r][c];
      if (p && p.type==='k' && p.color===color) return {r,c};
    }
    return null;
  }

  // Is square r,c attacked by `color`?
  isAttacked(r, c, byColor, board = this.board) {
    // pawn attacks
    const dir = byColor === WHITE ? -1 : 1;
    for (const dc of [-1,1]) {
      const rr = r + dir, cc = c + dc;
      if (this.inBounds(rr,cc)) {
        const p = board[rr][cc];
        if (p && p.color===byColor && p.type==='p') return true;
      }
    }
    // knight
    const knightMoves = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
    for (const [dr,dc] of knightMoves) {
      const rr=r+dr, cc=c+dc;
      if (this.inBounds(rr,cc)) {
        const p = board[rr][cc];
        if (p && p.color===byColor && p.type==='n') return true;
      }
    }
    // king
    for (let dr=-1;dr<=1;dr++) for (let dc=-1;dc<=1;dc++) {
      if (dr===0&&dc===0) continue;
      const rr=r+dr, cc=c+dc;
      if (this.inBounds(rr,cc)) {
        const p = board[rr][cc];
        if (p && p.color===byColor && p.type==='k') return true;
      }
    }
    // sliding: rook/queen (straight)
    const straight = [[-1,0],[1,0],[0,-1],[0,1]];
    for (const [dr,dc] of straight) {
      let rr=r+dr, cc=c+dc;
      while (this.inBounds(rr,cc)) {
        const p = board[rr][cc];
        if (p) {
          if (p.color===byColor && (p.type==='r'||p.type==='q')) return true;
          break;
        }
        rr+=dr; cc+=dc;
      }
    }
    // sliding: bishop/queen (diagonal)
    const diag = [[-1,-1],[-1,1],[1,-1],[1,1]];
    for (const [dr,dc] of diag) {
      let rr=r+dr, cc=c+dc;
      while (this.inBounds(rr,cc)) {
        const p = board[rr][cc];
        if (p) {
          if (p.color===byColor && (p.type==='b'||p.type==='q')) return true;
          break;
        }
        rr+=dr; cc+=dc;
      }
    }
    return false;
  }

  inCheck(color, board = this.board) {
    const k = board === this.board ? this.findKing(color) : this._findKingOn(board, color);
    if (!k) return false;
    return this.isAttacked(k.r, k.c, color===WHITE?BLACK:WHITE, board);
  }

  _findKingOn(board, color) {
    for (let r=0;r<8;r++) for (let c=0;c<8;c++) {
      const p = board[r][c];
      if (p && p.type==='k' && p.color===color) return {r,c};
    }
    return null;
  }

  // Pseudo-legal moves for a piece (no self-check filtering)
  pseudoMoves(r, c) {
    const p = this.board[r][c];
    if (!p) return [];
    const moves = [];
    const add = (rr,cc,flags={}) => { if (this.inBounds(rr,cc)) moves.push({from:{r,c}, to:{r:rr,c:cc}, ...flags}); };

    if (p.type === 'p') {
      const dir = p.color===WHITE ? -1 : 1;
      const startRow = p.color===WHITE ? 6 : 1;
      const promoRow = p.color===WHITE ? 0 : 7;
      // forward
      if (this.inBounds(r+dir,c) && !this.board[r+dir][c]) {
        if (r+dir === promoRow) {
          for (const promo of ['q','r','b','n']) add(r+dir,c,{promotion:promo});
        } else {
          add(r+dir,c);
        }
        if (r===startRow && !this.board[r+2*dir][c]) add(r+2*dir,c,{doubleStep:true});
      }
      // captures
      for (const dc of [-1,1]) {
        const rr=r+dir, cc=c+dc;
        if (this.inBounds(rr,cc)) {
          const target = this.board[rr][cc];
          if (target && target.color!==p.color) {
            if (rr===promoRow) {
              for (const promo of ['q','r','b','n']) add(rr,cc,{promotion:promo, capture:true});
            } else {
              add(rr,cc,{capture:true});
            }
          } else if (!target && this.enPassant && this.enPassant.r===rr && this.enPassant.c===cc) {
            add(rr,cc,{enPassantCapture:true, capture:true});
          }
        }
      }
    } else if (p.type === 'n') {
      const knightMoves = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
      for (const [dr,dc] of knightMoves) {
        const rr=r+dr, cc=c+dc;
        if (this.inBounds(rr,cc)) {
          const target = this.board[rr][cc];
          if (!target || target.color!==p.color) add(rr,cc,{capture:!!target});
        }
      }
    } else if (p.type === 'k') {
      for (let dr=-1;dr<=1;dr++) for (let dc=-1;dc<=1;dc++) {
        if (dr===0&&dc===0) continue;
        const rr=r+dr, cc=c+dc;
        if (this.inBounds(rr,cc)) {
          const target = this.board[rr][cc];
          if (!target || target.color!==p.color) add(rr,cc,{capture:!!target});
        }
      }
      // castling
      const homeRow = p.color===WHITE ? 7 : 0;
      if (r===homeRow && c===4 && !this.inCheck(p.color)) {
        const kSide = p.color===WHITE ? this.castling.wK : this.castling.bK;
        const qSide = p.color===WHITE ? this.castling.wQ : this.castling.bQ;
        const oppColor = p.color===WHITE?BLACK:WHITE;
        if (kSide && !this.board[homeRow][5] && !this.board[homeRow][6] &&
            this.board[homeRow][7] && this.board[homeRow][7].type==='r' &&
            !this.isAttacked(homeRow,5,oppColor) && !this.isAttacked(homeRow,6,oppColor)) {
          add(homeRow,6,{castle:'K'});
        }
        if (qSide && !this.board[homeRow][3] && !this.board[homeRow][2] && !this.board[homeRow][1] &&
            this.board[homeRow][0] && this.board[homeRow][0].type==='r' &&
            !this.isAttacked(homeRow,3,oppColor) && !this.isAttacked(homeRow,2,oppColor)) {
          add(homeRow,2,{castle:'Q'});
        }
      }
    } else {
      // sliding pieces
      let dirs = [];
      if (p.type==='r') dirs = [[-1,0],[1,0],[0,-1],[0,1]];
      else if (p.type==='b') dirs = [[-1,-1],[-1,1],[1,-1],[1,1]];
      else if (p.type==='q') dirs = [[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[-1,1],[1,-1],[1,1]];
      for (const [dr,dc] of dirs) {
        let rr=r+dr, cc=c+dc;
        while (this.inBounds(rr,cc)) {
          const target = this.board[rr][cc];
          if (!target) { add(rr,cc); }
          else { if (target.color!==p.color) add(rr,cc,{capture:true}); break; }
          rr+=dr; cc+=dc;
        }
      }
    }
    return moves;
  }

  // Apply move to a board copy, return new board (does not mutate state)
  simulateMove(board, move) {
    const b = cloneBoard(board);
    const p = b[move.from.r][move.from.c];
    b[move.from.r][move.from.c] = null;
    if (move.enPassantCapture) {
      const capRow = move.from.r; // captured pawn is on same row as mover, same col as dest
      b[capRow][move.to.c] = null;
    }
    b[move.to.r][move.to.c] = move.promotion ? { type: move.promotion, color: p.color } : p;
    if (move.castle === 'K') {
      const row = move.from.r;
      b[row][5] = b[row][7]; b[row][7] = null;
    } else if (move.castle === 'Q') {
      const row = move.from.r;
      b[row][3] = b[row][0]; b[row][0] = null;
    }
    return b;
  }

  // Legal moves for a square (filters out moves leaving own king in check)
  legalMoves(r,c) {
    const p = this.board[r][c];
    if (!p) return [];
    const pseudo = this.pseudoMoves(r,c);
    return pseudo.filter(m => {
      const b = this.simulateMove(this.board, m);
      return !this.inCheck(p.color, b);
    });
  }

  allLegalMoves(color) {
    const moves = [];
    for (let r=0;r<8;r++) for (let c=0;c<8;c++) {
      const p = this.board[r][c];
      if (p && p.color===color) moves.push(...this.legalMoves(r,c));
    }
    return moves;
  }

  makeMove(move) {
    const p = this.board[move.from.r][move.from.c];
    if (!p) return false;
    const captured = this.board[move.to.r][move.to.c];
    const isEnPassant = !!move.enPassantCapture;
    const snapshot = {
      board: cloneBoard(this.board),
      turn: this.turn,
      castling: {...this.castling},
      enPassant: this.enPassant ? {...this.enPassant} : null,
      halfmove: this.halfmove,
      fullmove: this.fullmove,
      move: {...move, pieceType: p.type, pieceColor: p.color, capturedType: captured?captured.type:(isEnPassant?'p':null)}
    };

    // capture bookkeeping
    if (captured) this.captured[p.color].push(captured.type);
    else if (isEnPassant) this.captured[p.color].push('p');

    this.board = this.simulateMove(this.board, move);

    // update castling rights
    if (p.type==='k') {
      if (p.color===WHITE) { this.castling.wK=false; this.castling.wQ=false; }
      else { this.castling.bK=false; this.castling.bQ=false; }
    }
    if (p.type==='r') {
      if (move.from.r===7 && move.from.c===0) this.castling.wQ=false;
      if (move.from.r===7 && move.from.c===7) this.castling.wK=false;
      if (move.from.r===0 && move.from.c===0) this.castling.bQ=false;
      if (move.from.r===0 && move.from.c===7) this.castling.bK=false;
    }
    // rook captured on home square removes castling rights too
    if (move.to.r===7 && move.to.c===0) this.castling.wQ=false;
    if (move.to.r===7 && move.to.c===7) this.castling.wK=false;
    if (move.to.r===0 && move.to.c===0) this.castling.bQ=false;
    if (move.to.r===0 && move.to.c===7) this.castling.bK=false;

    // en passant target
    if (move.doubleStep) {
      this.enPassant = { r: (move.from.r+move.to.r)/2, c: move.from.c };
    } else {
      this.enPassant = null;
    }

    // halfmove clock
    if (p.type==='p' || captured || isEnPassant) this.halfmove = 0;
    else this.halfmove++;

    if (this.turn === BLACK) this.fullmove++;
    this.turn = this.turn===WHITE ? BLACK : WHITE;

    this.history.push(snapshot);
    this.updateGameStatus();
    return true;
  }

  undo() {
    if (this.history.length===0) return false;
    const snap = this.history.pop();
    this.board = snap.board;
    this.turn = snap.turn;
    this.castling = snap.castling;
    this.enPassant = snap.enPassant;
    this.halfmove = snap.halfmove;
    this.fullmove = snap.fullmove;
    // undo capture bookkeeping
    const mv = snap.move;
    if (mv.capturedType) {
      const arr = this.captured[mv.pieceColor];
      const idx = arr.lastIndexOf(mv.capturedType);
      if (idx>-1) arr.splice(idx,1);
    }
    this.gameOver = false;
    this.result = null;
    this.winner = null;
    return true;
  }

  updateGameStatus() {
    const moves = this.allLegalMoves(this.turn);
    const inCheck = this.inCheck(this.turn);
    if (moves.length === 0) {
      this.gameOver = true;
      if (inCheck) {
        this.result = 'checkmate';
        this.winner = this.turn===WHITE ? BLACK : WHITE;
      } else {
        this.result = 'stalemate';
        this.winner = null;
      }
    } else if (this.halfmove >= 100) {
      this.gameOver = true;
      this.result = 'draw';
      this.winner = null;
    } else if (this.insufficientMaterial()) {
      this.gameOver = true;
      this.result = 'draw';
      this.winner = null;
    }
  }

  insufficientMaterial() {
    const pieces = [];
    for (let r=0;r<8;r++) for (let c=0;c<8;c++) {
      const p = this.board[r][c];
      if (p && p.type!=='k') pieces.push(p.type);
    }
    if (pieces.length===0) return true;
    if (pieces.length===1 && (pieces[0]==='n'||pieces[0]==='b')) return true;
    return false;
  }

  isInCheckNow() { return this.inCheck(this.turn); }

  algebraic(r,c) {
    return 'abcdefgh'[c] + (8-r);
  }
}
