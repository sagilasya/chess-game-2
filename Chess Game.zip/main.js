(function () {
  const PIECE_UNICODE = {
    w: { k:'♔', q:'♕', r:'♖', b:'♗', n:'♘', p:'♙' },
    b: { k:'♚', q:'♛', r:'♜', b:'♝', n:'♞', p:'♟' }
  };

  // ---------- state ----------
  let settings = { mode:'ai', difficulty:'medium', side:'w', time:300, theme:'classic' };
  let game = null;
  let sound = new SoundEngine();
  let timer = null;
  let humanColor = 'w';
  let boardFlipped = false;
  let selected = null; // {r,c}
  let legalTargets = []; // moves for selected piece
  let gameId = 0; // guards stale async AI moves
  let paused = false;
  let pendingPromotion = null; // {from, to}
  let lastMove = null;

  // ---------- DOM refs ----------
  const $ = id => document.getElementById(id);
  const boardEl = $('board');
  const statusText = $('status-text');
  const moveListEl = $('move-list');

  // ---------- setup screen wiring ----------
  function wireOptionRow(rowId, key, extra) {
    const row = $(rowId);
    row.addEventListener('click', e => {
      const btn = e.target.closest('.opt-btn');
      if (!btn) return;
      [...row.children].forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      settings[key] = btn.dataset.value;
      if (extra) extra(btn.dataset.value);
    });
  }
  wireOptionRow('mode-row', 'mode', v => {
    $('difficulty-group').style.display = v==='ai' ? '' : 'none';
    $('side-group').style.display = v==='ai' ? '' : 'none';
  });
  wireOptionRow('difficulty-row', 'difficulty');
  wireOptionRow('side-row', 'side');
  wireOptionRow('time-row', 'time');
  wireOptionRow('theme-row', 'theme');

  $('start-btn').addEventListener('click', startGame);

  // ---------- game start ----------
  function startGame() {
    gameId++;
    const myId = gameId;
    game = new ChessGame();
    paused = false;
    selected = null;
    legalTargets = [];
    lastMove = null;
    pendingPromotion = null;

    humanColor = settings.side === 'random'
      ? (Math.random() < 0.5 ? 'w' : 'b')
      : (settings.mode === '2p' ? 'w' : settings.side);
    boardFlipped = humanColor === 'b';

    document.body.dataset.theme = settings.theme;

    const secs = parseInt(settings.time, 10);
    timer = new ChessTimer(secs || 0, updateTimerDisplay, onFlag);

    $('top-name').textContent = boardFlipped ? 'White' : 'Black';
    $('bottom-name').textContent = boardFlipped ? 'Black' : 'White';

    updateTimerDisplay(timer.times);
    if (secs > 0) timer.start(game.turn);

    switchScreen('game-screen');
    renderBoard();
    updateStatus();
    renderCaptured();
    renderMoveList();
    maybeTriggerAI(myId);
  }

  function switchScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    $(id).classList.add('active');
  }

  // ---------- board rendering ----------
  function squareCoords(r, c) {
    // apply flip for display
    return boardFlipped ? { dr: 7-r, dc: 7-c } : { dr: r, dc: c };
  }
  function displayToBoard(dr, dc) {
    return boardFlipped ? { r: 7-dr, c: 7-dc } : { r: dr, c: dc };
  }

  function renderBoard() {
    boardEl.innerHTML = '';
    boardEl.dataset.theme = settings.theme;
    for (let dr = 0; dr < 8; dr++) {
      for (let dc = 0; dc < 8; dc++) {
        const { r, c } = displayToBoard(dr, dc);
        const sq = document.createElement('div');
        const isLight = (r + c) % 2 === 0;
        sq.className = 'square ' + (isLight ? 'light' : 'dark');
        sq.dataset.r = r; sq.dataset.c = c;

        if (lastMove && ((lastMove.from.r===r && lastMove.from.c===c) || (lastMove.to.r===r && lastMove.to.c===c))) {
          sq.classList.add('last-move');
        }
        if (selected && selected.r===r && selected.c===c) sq.classList.add('selected');

        const piece = game.board[r][c];
        if (piece && piece.type==='k' && game.isInCheckNow && game.turn===piece.color && game.inCheck(piece.color)) {
          sq.classList.add('in-check');
        }

        if (piece) {
          const span = document.createElement('span');
          span.className = 'piece ' + (piece.color==='w' ? 'white' : 'black');
          span.textContent = PIECE_UNICODE[piece.color][piece.type];
          sq.appendChild(span);
        }

        const target = legalTargets.find(m => m.to.r===r && m.to.c===c);
        if (target) {
          const dot = document.createElement('div');
          dot.className = target.capture ? 'capture-ring' : 'move-dot';
          sq.appendChild(dot);
        }

        // coordinate labels on edge squares
        if (dc === 0) {
          const lbl = document.createElement('span');
          lbl.className = 'coord-label rank';
          lbl.textContent = 8 - r;
          lbl.style.color = isLight ? 'var(--board-dark)' : 'var(--board-light)';
          sq.appendChild(lbl);
        }
        if (dr === 7) {
          const lbl = document.createElement('span');
          lbl.className = 'coord-label file';
          lbl.textContent = 'abcdefgh'[c];
          lbl.style.color = isLight ? 'var(--board-dark)' : 'var(--board-light)';
          sq.appendChild(lbl);
        }

        sq.addEventListener('click', () => onSquareClick(r, c));
        boardEl.appendChild(sq);
      }
    }
  }

  function isHumanTurn() {
    if (paused || game.gameOver || pendingPromotion) return false;
    if (settings.mode === '2p') return true;
    return game.turn === humanColor;
  }

  function onSquareClick(r, c) {
    if (!isHumanTurn()) return;
    const piece = game.board[r][c];

    if (selected) {
      const move = legalTargets.find(m => m.to.r===r && m.to.c===c);
      if (move) {
        if (move.promotion) {
          // ask which promotion piece (default queen move used to find r,c; regenerate options)
          pendingPromotion = { from: selected, to: {r,c}, color: game.board[selected.r][selected.c].color };
          showPromotionModal();
          return;
        }
        performMove(move);
        return;
      }
      // clicking own piece elsewhere reselects
      if (piece && piece.color === game.turn) {
        selectSquare(r,c);
      } else {
        selected = null; legalTargets = [];
        renderBoard();
      }
      return;
    }

    if (piece && piece.color === game.turn) {
      selectSquare(r,c);
    }
  }

  function selectSquare(r,c) {
    selected = {r,c};
    legalTargets = game.legalMoves(r,c);
    renderBoard();
  }

  function showPromotionModal() {
    const modal = $('promotion-modal');
    const opts = $('promotion-options');
    opts.innerHTML = '';
    const color = pendingPromotion.color;
    ['q','r','b','n'].forEach(type => {
      const btn = document.createElement('button');
      btn.textContent = PIECE_UNICODE[color][type];
      btn.addEventListener('click', () => {
        const move = { from: pendingPromotion.from, to: pendingPromotion.to, promotion: type, capture: !!game.board[pendingPromotion.to.r][pendingPromotion.to.c] };
        modal.classList.add('hidden');
        pendingPromotion = null;
        performMove(move);
      });
      opts.appendChild(btn);
    });
    modal.classList.remove('hidden');
  }

  function performMove(move) {
    const myId = gameId;
    const wasCapture = !!game.board[move.to.r][move.to.c] || move.enPassantCapture;
    const isCastle = !!move.castle;
    const movingPiece = game.board[move.from.r][move.from.c];

    game.makeMove(move);
    lastMove = move;
    selected = null; legalTargets = [];

    if (timer && timer.initialSeconds > 0) timer.switchTo(game.turn);

    // sound
    if (game.gameOver && game.result==='checkmate') {
      // handled after status update
    } else if (game.isInCheckNow()) {
      sound.check();
    } else if (move.promotion) {
      sound.promote();
    } else if (isCastle) {
      sound.castle();
    } else if (wasCapture) {
      sound.capture();
    } else {
      sound.move();
    }

    renderBoard();
    renderCaptured();
    renderMoveList();
    updateStatus();

    if (game.gameOver) {
      finishGame();
      return;
    }

    maybeTriggerAI(myId);
  }

  function maybeTriggerAI(myId) {
    if (settings.mode !== 'ai') return;
    if (game.turn === humanColor) return;
    if (game.gameOver || paused) return;

    statusText.textContent = 'Thinking…';
    setTimeout(() => {
      if (myId !== gameId) return; // stale game guard
      if (paused || game.gameOver) return;
      const move = getAIMove(game, settings.difficulty);
      if (!move) return;
      if (myId !== gameId) return;
      performMove(move);
    }, 350 + Math.random()*300);
  }

  // ---------- status / captured / move list ----------
  function pieceLetterName(t) {
    return { p:'Pawn', n:'Knight', b:'Bishop', r:'Rook', q:'Queen', k:'King' }[t];
  }

  function updateStatus() {
    if (game.gameOver) return; // result overlay handles this
    const turnName = game.turn === 'w' ? 'White' : 'Black';
    if (game.isInCheckNow()) {
      statusText.textContent = `${turnName} is in check`;
    } else {
      statusText.textContent = `${turnName} to move`;
    }
  }

  function renderCaptured() {
    const topColor = boardFlipped ? 'w' : 'b';
    const bottomColor = boardFlipped ? 'b' : 'w';
    // captured[color] = pieces that `color` has captured (opponent pieces)
    const order = { q:0, r:1, b:2, n:3, p:4 };
    const fmt = (color) => game.captured[color]
      .slice()
      .sort((a,b) => order[a]-order[b])
      .map(t => PIECE_UNICODE[color==='w' ? 'b':'w'][t])
      .join(' ');
    $('top-captured').textContent = fmt(topColor);
    $('bottom-captured').textContent = fmt(bottomColor);
  }

  function renderMoveList() {
    moveListEl.innerHTML = '';
    const hist = game.history;
    for (let i = 0; i < hist.length; i += 2) {
      const num = i/2 + 1;
      const w = hist[i] ? moveNotation(hist[i].move) : '';
      const b = hist[i+1] ? moveNotation(hist[i+1].move) : '';
      const numEl = document.createElement('span'); numEl.className='mv-num'; numEl.textContent = num+'.';
      const wEl = document.createElement('span'); wEl.className='mv-white'; wEl.textContent = w;
      const bEl = document.createElement('span'); bEl.className='mv-black'; bEl.textContent = b;
      moveListEl.appendChild(numEl); moveListEl.appendChild(wEl); moveListEl.appendChild(bEl);
    }
    const wrap = moveListEl.parentElement;
    wrap.scrollTop = wrap.scrollHeight;
  }

  function moveNotation(move) {
    if (move.castle === 'K') return 'O-O';
    if (move.castle === 'Q') return 'O-O-O';
    const files = 'abcdefgh';
    const pieceLetter = move.pieceType==='p' ? '' : move.pieceType.toUpperCase();
    const from = files[move.from.c] + (8-move.from.r);
    const to = files[move.to.c] + (8-move.to.r);
    const capture = (move.capture || move.capturedType) ? 'x' : '';
    let notation;
    if (move.pieceType === 'p' && capture) {
      notation = files[move.from.c] + capture + to;
    } else {
      notation = pieceLetter + capture + to;
    }
    if (move.promotion) notation += '=' + move.promotion.toUpperCase();
    return notation;
  }

  // ---------- timer ----------
  function updateTimerDisplay(times) {
    const topColor = boardFlipped ? 'w' : 'b';
    const bottomColor = boardFlipped ? 'b' : 'w';
    const noLimit = timer.initialSeconds === 0;
    $('top-timer').textContent = noLimit ? '∞' : timer.formatTime(times[topColor]);
    $('bottom-timer').textContent = noLimit ? '∞' : timer.formatTime(times[bottomColor]);

    $('top-timer').classList.toggle('active', game && !game.gameOver && game.turn===topColor && !paused);
    $('bottom-timer').classList.toggle('active', game && !game.gameOver && game.turn===bottomColor && !paused);
    $('top-timer').classList.toggle('low', times[topColor] <= 30 && times[topColor] > 0);
    $('bottom-timer').classList.toggle('low', times[bottomColor] <= 30 && times[bottomColor] > 0);
  }

  function onFlag(color) {
    if (!game || game.gameOver) return;
    game.gameOver = true;
    game.result = 'timeout';
    game.winner = color === 'w' ? 'b' : 'w';
    finishGame();
  }

  // ---------- game end ----------
  function finishGame() {
    if (timer) timer.stop();
    let title, subtitle, icon, soundResult;

    if (game.result === 'checkmate') {
      title = 'Checkmate';
      subtitle = (game.winner === 'w' ? 'White' : 'Black') + ' wins';
      icon = '♚';
    } else if (game.result === 'timeout') {
      title = 'Time Out';
      subtitle = (game.winner === 'w' ? 'White' : 'Black') + ' wins on time';
      icon = '⏰';
    } else if (game.result === 'resign') {
      title = 'Resignation';
      subtitle = (game.winner === 'w' ? 'White' : 'Black') + ' wins';
      icon = '🏳';
    } else if (game.result === 'stalemate') {
      title = 'Stalemate';
      subtitle = 'Draw';
      icon = '½';
    } else if (game.result === 'draw-agreement') {
      title = 'Draw Agreed';
      subtitle = 'Draw';
      icon = '½';
    } else {
      title = 'Draw';
      subtitle = 'Draw by rule';
      icon = '½';
    }

    if (settings.mode === 'ai' && game.winner) {
      soundResult = game.winner === humanColor ? 'win' : 'loss';
    } else if (!game.winner) {
      soundResult = 'draw';
    } else {
      soundResult = 'win';
    }
    sound.gameEnd(soundResult);

    $('result-icon').textContent = icon;
    $('result-title').textContent = title;
    $('result-subtitle').textContent = subtitle;
    $('result-overlay').classList.remove('hidden');
    statusText.textContent = title;
  }

  // ---------- controls ----------
  $('menu-btn').addEventListener('click', () => {
    gameId++;
    if (timer) timer.stop();
    switchScreen('setup-screen');
  });

  $('sound-btn').addEventListener('click', () => {
    sound.enabled = !sound.enabled;
    $('sound-btn').textContent = sound.enabled ? '🔊' : '🔇';
  });

  $('undo-btn').addEventListener('click', () => {
    if (!game || game.history.length===0) return;
    gameId++; // cancel any pending AI move
    const myId = gameId;
    if (settings.mode === 'ai' && game.history.length >= 1) {
      // undo both the AI move and the human move if possible
      game.undo();
      if (game.history.length && game.turn !== humanColor) game.undo();
    } else {
      game.undo();
    }
    selected = null; legalTargets = [];
    lastMove = game.history.length ? game.history[game.history.length-1].move : null;
    renderBoard(); renderCaptured(); renderMoveList(); updateStatus();
    if (timer && timer.initialSeconds > 0) timer.switchTo(game.turn);
    maybeTriggerAI(myId);
  });

  $('pause-btn').addEventListener('click', () => {
    if (!game || game.gameOver) return;
    paused = true;
    if (timer) timer.pause();
    $('pause-overlay').classList.remove('hidden');
  });
  $('resume-btn').addEventListener('click', () => {
    paused = false;
    if (timer) timer.resume();
    $('pause-overlay').classList.add('hidden');
  });
  $('pause-menu-btn').addEventListener('click', () => {
    gameId++;
    if (timer) timer.stop();
    $('pause-overlay').classList.add('hidden');
    switchScreen('setup-screen');
  });

  $('flip-btn').addEventListener('click', () => {
    boardFlipped = !boardFlipped;
    const t = $('top-name').textContent;
    $('top-name').textContent = $('bottom-name').textContent;
    $('bottom-name').textContent = t;
    renderBoard();
    if (timer) updateTimerDisplay(timer.times);
    renderCaptured();
  });

  $('draw-btn').addEventListener('click', () => {
    if (!game || game.gameOver) return;
    $('draw-overlay').classList.remove('hidden');
  });
  $('draw-cancel-btn').addEventListener('click', () => $('draw-overlay').classList.add('hidden'));
  $('draw-confirm-btn').addEventListener('click', () => {
    $('draw-overlay').classList.add('hidden');
    if (!game || game.gameOver) return;
    gameId++;
    game.gameOver = true;
    game.result = 'draw-agreement';
    game.winner = null;
    finishGame();
  });

  $('resign-btn').addEventListener('click', () => {
    if (!game || game.gameOver) return;
    $('resign-overlay').classList.remove('hidden');
  });
  $('resign-cancel-btn').addEventListener('click', () => $('resign-overlay').classList.add('hidden'));
  $('resign-confirm-btn').addEventListener('click', () => {
    $('resign-overlay').classList.add('hidden');
    if (!game || game.gameOver) return;
    gameId++;
    game.gameOver = true;
    game.result = 'resign';
    const resigner = settings.mode==='2p' ? game.turn : humanColor;
    game.winner = resigner === 'w' ? 'b' : 'w';
    finishGame();
  });

  $('play-again-btn').addEventListener('click', () => {
    $('result-overlay').classList.add('hidden');
    startGame();
  });
  $('result-menu-btn').addEventListener('click', () => {
    $('result-overlay').classList.add('hidden');
    gameId++;
    switchScreen('setup-screen');
  });

  // init difficulty/side visibility on load
  $('difficulty-group').style.display = '';
  $('side-group').style.display = '';
})();
