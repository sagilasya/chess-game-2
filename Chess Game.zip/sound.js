// Sound effects synthesized via Web Audio API — no binary asset files needed
class SoundEngine {
  constructor() {
    this.enabled = true;
    this.ctx = null;
  }

  _ensureCtx() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AC();
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
    return this.ctx;
  }

  _tone(freq, duration, type='sine', gainVal=0.15, delay=0) {
    if (!this.enabled) return;
    try {
      const ctx = this._ensureCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(gainVal, ctx.currentTime + delay);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + delay);
      osc.stop(ctx.currentTime + delay + duration);
    } catch (e) { /* audio unsupported, ignore */ }
  }

  move() {
    this._tone(420, 0.09, 'triangle', 0.12);
  }

  capture() {
    this._tone(300, 0.08, 'square', 0.1);
    this._tone(220, 0.1, 'square', 0.08, 0.03);
  }

  check() {
    this._tone(660, 0.12, 'sawtooth', 0.12);
    this._tone(880, 0.12, 'sawtooth', 0.1, 0.07);
  }

  castle() {
    this._tone(392, 0.08, 'triangle', 0.12);
    this._tone(523, 0.08, 'triangle', 0.12, 0.06);
  }

  promote() {
    this._tone(523, 0.09, 'sine', 0.12);
    this._tone(659, 0.09, 'sine', 0.12, 0.08);
    this._tone(784, 0.14, 'sine', 0.12, 0.16);
  }

  gameEnd(win) {
    if (win === 'win') {
      [523, 659, 784, 1047].forEach((f,i) => this._tone(f, 0.18, 'triangle', 0.14, i*0.11));
    } else if (win === 'loss') {
      [400, 350, 300, 250].forEach((f,i) => this._tone(f, 0.22, 'sawtooth', 0.12, i*0.13));
    } else {
      [440, 440].forEach((f,i) => this._tone(f, 0.2, 'sine', 0.1, i*0.25));
    }
  }

  click() {
    this._tone(300, 0.04, 'square', 0.06);
  }

  setEnabled(v) { this.enabled = v; }
}
