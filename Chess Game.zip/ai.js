// Simple minimax AI with alpha-beta pruning and piece-square tables
const PIECE_VALUES = { p:100, n:320, b:330, r:500, q:900, k:20000 };

const PST = {
  p: [
    [0,0,0,0,0,0,0,0],
    [50,50,50,50,50,50,50,50],
    [10,10,20,30,30,20,10,10],
    [5,5,10,25,25,10,5,5],
    [0,0,0,20,20,0,0,0],
    [5,-5,-10,0,0,-10,-5,5],
    [5,10,10,-20,-20,10,10,5],
    [0,0,0,0,0,0,0,0]
  ],
  n: [
    [-50,-40,-30,-30,-30,-30,-40,-50],
    [-40,-20,0,0,0,0,-20,-40],
    [-30,0,10,15,15,10,0,-30],
    [-30,5,15,20,20,15,5,-30],
    [-30,0,15,20,20,15,0,-30],
    [-30,5,10,15,15,10,5,-30],
    [-40,-20,0,5,5,0,-20,-40],
    [-50,-40,-30,-30,-30,-30,-40,-50]
  ],
  b: [
    [-20,-10,-10,-10,-10,-10,-10,-20],
    [-10,0,0,0,0,0,0,-10],
    [-10,0,5,10,10,5,0,-10],
    [-10,5,5,10,10,5,5,-10],
    [-10,0,10,10,10,10,0,-10],
    [-10,10,10,10,10,10,10,-10],
    [-10,5,0,0,0,0,5,-10],
    [-20,-10,-10,-10,-10,-10,-10,-20]
  ],
  r: [
    [0,0,0,0,0,0,0,0],
    [5,10,10,10,10,10,10,5],
    [-5,0,0,0,0,0,0,-5],
    [-5,0,0,0,0,0,0,-5],
    [-5,0,0,0,0,0,0,-5],
    [-5,0,0,0,0,0,0,-5],
    [-5,0,0,0,0,0,0,-5],
    [0,0,0,5,5,0,0,0]
  ],
  q: [
    [-20,-10,-10,-5,-5,-10,-10,-20],
    [-10,0,0,0,0,0,0,-10],
    [-10,0,5,5,5,5,0,-10],
    [-5,0,5,5,5,5,0,-5],
    [0,0,5,5,5,5,0,-5],
    [-10,5,5,5,5,5,0,-10],
    [-10,0,5,0,0,0,0,-10],
    [-20,-10,-10,-5,-5,-10,-10,-20]
  ],
  k: [
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-20,-30,-30,-40,-40,-30,-30,-20],
    [-10,-20,-20,-20,-20,-20,-20,-10],
    [20,20,0,0,0,0,20,20],
    [20,30,10,0,0,10,30,20]
  ]
};

function evaluateBoard(game) {
  let score = 0;
  for (let r=0;r<8;r++) for (let c=0;c<8;c++) {
    const p = game.board[r][c];
    if (!p) continue;
    const val = PIECE_VALUES[p.type];
    const pstRow = p.color===WHITE ? r : 7-r;
    const pst = PST[p.type][pstRow][c];
    const total = val + pst;
    score += p.color===WHITE ? total : -total;
  }
  return score;
}

function orderMoves(moves) {
  return moves.slice().sort((a,b) => (b.capture?1:0) - (a.capture?1:0));
}

function minimax(game, depth, alpha, beta, maximizing) {
  if (depth === 0 || game.gameOver) {
    if (game.gameOver && game.result === 'checkmate') {
      return maximizing ? -100000 - depth : 100000 + depth;
    }
    return evaluateBoard(game);
  }
  const color = maximizing ? WHITE : BLACK;
  const moves = orderMoves(game.allLegalMoves(color));
  if (moves.length === 0) {
    return game.inCheck(color) ? (maximizing ? -100000-depth : 100000+depth) : 0;
  }
  if (maximizing) {
    let best = -Infinity;
    for (const m of moves) {
      game.makeMove(m);
      const val = minimax(game, depth-1, alpha, beta, false);
      game.undo();
      best = Math.max(best, val);
      alpha = Math.max(alpha, val);
      if (beta <= alpha) break;
    }
    return best;
  } else {
    let best = Infinity;
    for (const m of moves) {
      game.makeMove(m);
      const val = minimax(game, depth-1, alpha, beta, true);
      game.undo();
      best = Math.min(best, val);
      beta = Math.min(beta, val);
      if (beta <= alpha) break;
    }
    return best;
  }
}

function getAIMove(game, difficulty) {
  const depth = difficulty === 'easy' ? 1 : difficulty === 'medium' ? 2 : 3;
  const color = game.turn;
  const maximizing = color === WHITE;
  let moves = orderMoves(game.allLegalMoves(color));
  if (moves.length === 0) return null;

  // easy mode: add randomness by sometimes picking a random legal move
  if (difficulty === 'easy' && Math.random() < 0.3) {
    return moves[Math.floor(Math.random()*moves.length)];
  }

  let bestMove = moves[0];
  let bestVal = maximizing ? -Infinity : Infinity;
  let alpha = -Infinity, beta = Infinity;
  const scored = [];

  for (const m of moves) {
    game.makeMove(m);
    const val = minimax(game, depth-1, alpha, beta, !maximizing);
    game.undo();
    scored.push({m, val});
    if (maximizing) {
      if (val > bestVal) { bestVal = val; bestMove = m; }
      alpha = Math.max(alpha, val);
    } else {
      if (val < bestVal) { bestVal = val; bestMove = m; }
      beta = Math.min(beta, val);
    }
  }

  // medium: occasionally pick a near-best move instead of the top move
  if (difficulty === 'medium') {
    scored.sort((a,b) => maximizing ? b.val-a.val : a.val-b.val);
    const topN = scored.slice(0, Math.min(3, scored.length));
    if (Math.random() < 0.35) {
      return topN[Math.floor(Math.random()*topN.length)].m;
    }
  }

  return bestMove;
}
