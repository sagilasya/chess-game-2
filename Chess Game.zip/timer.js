// Per-player countdown timer
class ChessTimer {
  constructor(initialSeconds, onTick, onFlag) {
    this.initialSeconds = initialSeconds;
    this.times = { w: initialSeconds, b: initialSeconds };
    this.activeColor = null;
    this.interval = null;
    this.onTick = onTick;
    this.onFlag = onFlag;
    this.paused = true;
  }

  reset(seconds) {
    this.stop();
    this.initialSeconds = seconds;
    this.times = { w: seconds, b: seconds };
    this.activeColor = null;
    this.paused = true;
  }

  start(color) {
    this.stop();
    this.activeColor = color;
    this.paused = false;
    this.interval = setInterval(() => {
      if (this.paused) return;
      this.times[this.activeColor] = Math.max(0, this.times[this.activeColor] - 1);
      if (this.onTick) this.onTick(this.times);
      if (this.times[this.activeColor] <= 0) {
        this.stop();
        if (this.onFlag) this.onFlag(this.activeColor);
      }
    }, 1000);
  }

  switchTo(color) {
    this.activeColor = color;
  }

  pause() { this.paused = true; }
  resume() { this.paused = false; }

  stop() {
    if (this.interval) clearInterval(this.interval);
    this.interval = null;
  }

  formatTime(seconds) {
    const m = Math.floor(seconds/60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2,'0')}`;
  }
}
